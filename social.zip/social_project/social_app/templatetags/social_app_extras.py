from django import template

register = template.Library()

@register.filter()
def range_func(mini,maxi):
    return range(mini,maxi)