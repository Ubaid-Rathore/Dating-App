from django.shortcuts import render
from .models import UserProfile,UserDetail
from .forms import UserDetailForm
from django.shortcuts import redirect,get_object_or_404
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.urlresolvers import reverse
# Create your views here.
from django.contrib.auth.models import User
from django.contrib import messages
from django.views.generic import DetailView,View,ListView,CreateView,UpdateView
from django.views.generic.edit import BaseCreateView

def home(request):
	return render(request,'social_app/home.html')



def contact(request):
	return render(request,'social_app/contact.html')

def register(request):

	user = UserProfile()

	if request.method == 'POST':

			username = request.POST.get('Username')
			email = request.POST.get('email')
			password = request.POST.get('Password')
			user.confirm_password = request.POST.get('ConfirmPassword')
			user.age = request.POST.get('Age')
			user.gender = request.POST.get('gender')
			hey = User.objects.create_user(username= username, password= password,email =  email)
			user.user = hey
			user.save()
			hey.save()
			User_objects_username = User.objects.filter(username = username)
			User_objects_email = User.objects.filter(email = email)

			if User_objects_username.exists():
				messages.add_message(request, messages.INFO, 'Username Already exists')

			elif User_objects_email.exists():
				messages.add_message(request, messages.INFO, 'Email Already exists')
				

			return redirect('/login/')
			



	return render(request,'social_app/register.html',{'user':user})	

@login_required
def logout_user(request):
	logout(request)
	return redirect('/register/')
	

def login_user(request):

	if request.method == 'POST':
		username = request.POST.get('Username')
		password = request.POST.get('Password')


		user = authenticate(username =username, password =password)

		if user:
			if user.is_active:
				login(request,user)
				return HttpResponseRedirect('/home/')

		else:
			messages.add_message(request, messages.INFO, 'Incorrect! Please check you,r username or password')
			
			
	return render(request,'social_app/login.html')				


def profile_details(request):
	return render(request,'social_app/profile-details.html')		

@login_required
def profile(request,pk):
	user_detail = UserDetail.objects.all()
	return render(request,'social_app/profile.html',{'user_detail':user_detail,})


class Create_View(CreateView):
	model = UserDetail
	template_name = 'social_app/profile-create.html'
	fields = ['enthicity','You_work_as','image','cover_image','country','height','birth_date','smoking','relationship','looking_for','diet','kids','eye_color','status','hobby',]

from django.views.generic.detail import SingleObjectTemplateResponseMixin
from django.views.generic.edit import ModelFormMixin, ProcessFormView


class Update_View(UpdateView):
	def get_object(self, queryset=None):
		try:
			obj = None
		except ObjectDoesNotExist:
			raise Http404(_("No %(verbose_name)s found matching the query") %
				{'verbose_name': queryset.model._meta.verbose_name})

		return obj

	
	def get(self, request, *args, **kwargs):
		self.object = None
		return super(Update_View, self).get(request, *args, **kwargs)

	def post(self, request, *args, **kwargs):
		self.object = None
		return super(Update_View, self).post(request, *args, **kwargs)

	model = UserDetail
	form_class = UserDetailForm
	template_name = "social_app/profile-create.html"

