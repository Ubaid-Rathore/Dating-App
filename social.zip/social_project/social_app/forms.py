from django import forms
from .models import UserProfile,UserDetail
from django.contrib.auth.models import User


class UserForm(forms.ModelForm):
	password = forms.CharField(widget = forms.PasswordInput())

	class Meta:
		model = User
		fields = ('username','email','password')


class UserProfileForm(forms.ModelForm):

	confirm_password = forms.CharField(widget = forms.PasswordInput())


	class Meta:
		model = UserProfile
		fields = ('confirm_password',)





class UserDetailForm(forms.ModelForm):

	class Meta:
		model = UserDetail
		fields = ('enthicity','You_work_as','image','cover_image','country','height','birth_date','smoking','relationship','looking_for','diet','kids','eye_color','status','hobby',)