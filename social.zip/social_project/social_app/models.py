from django.db import models
from django.contrib.auth.models import User
# Create your models here.    
import datetime
from django.shortcuts import redirect
from django.core.validators import MaxValueValidator, MinValueValidator
from django_countries.fields import CountryField

from django.core.urlresolvers import reverse
from django.utils.text import slugify

class UserProfile(models.Model):

	user = models.OneToOneField(User)

	confirm_password = models.CharField(max_length = 20)

	age = models.CharField(max_length = 50)

	gender = models.CharField(max_length = 30,default = 'Male')

	pub_date = models.DateTimeField(auto_now_add = True)


	def __str__(self):
		return self.user.username
	



class UserDetail(models.Model):


		user = models.ForeignKey(UserProfile,default = 1)

		image = models.ImageField(upload_to =' images',default = '/media/user.png')

		ETHNIC_CHOICES = (
		('Asian','Asian'),
		('American','American'),
		('European','European'),
		('African','African'),
		('Other','Other')

			)

		enthicity = models.CharField(choices = ETHNIC_CHOICES,max_length = 30,default = 'Male')

		YOU_WORK_AS_CHOICES = (
		 ('Profession','Profession'),
		 ('Doctor','Doctor'),
		 ('Engineer','Engineer'),
		 ('Entrepreneur','Entrepreneur'),
		 ('Technician','Technician'),
		 ('Model','Model'),
		 ('Other','Other'),
		
		)

		You_work_as = models.CharField(choices = YOU_WORK_AS_CHOICES,max_length = 30,default = 'Entrepreneur')

		cover_image = models.ImageField(upload_to = 'images',default = '/media/dating.png')

		country = CountryField()

		height = models.PositiveIntegerField(default = 110 , validators=[MaxValueValidator(215), MinValueValidator(70)])

		birth_date = models.DateField(("Date"), default=datetime.date.today)

		smoking = models.CharField(max_length = 30,default = 'No')

		RELATIONSHIP_CHOICES = (
		 ('SINGLE','single'),
		 ('DIVORCED','divorced'),
		 ('MARRIED','married'),

		 )

		relationship = models.CharField(choices = RELATIONSHIP_CHOICES,max_length = 30,default = 'SINGLE')

		LOOKING_CHOICES = (
		 ('MAN','Man'),
		 ('WOMAN','Woman'),
		 )

		looking_for = models.CharField(choices = LOOKING_CHOICES,max_length = 30,default = 'MAN')

		DIET_CHOICES = (
		 ('VEGETARIAN','vegitarian'),
		 ('NON_VEG','Non-Vegitarian'),

		 )

		diet = models.CharField(choices = DIET_CHOICES , max_length = 30,default = 'VEGETARIAN')

		KIDS_CHOICES = (

		 ('YES','Yes'),
		 ('NO','No'),
		 ('SOME_DAY','Some day')

		 )

		kids = models.CharField(choices = KIDS_CHOICES , max_length = 30,default = 'YES')




		eye_color = models.CharField(max_length = 10,default = 'Brown')
		
		STATUS_CHOICES = (
			('MARRIED','Married'),
			('SINGLE','Single'),
			('DIVORCED','Divorced'),
			)
		status = models.CharField(choices = STATUS_CHOICES,max_length = 30,default = 'MARRIED')
		
		hobby = models.CharField(max_length = 30,default = 'Kissing')


		def get_absolute_url(self):
			return reverse('social_app:profile',kwargs = {'pk':self.pk})

		def save(self, *args, **kwargs):
			super(UserDetail,self).save(*args, **kwargs)
        

	