from django.conf.urls import url
from . import views

app_name = "social_app"

urlpatterns = [

url(r'^home/$',views.home,name = 'home'),
url(r'^contact/$',views.contact,name = 'contact' ),
url(r'^login/$',views.login_user,name = 'login_user'),
url(r'^logout/$',views.logout_user,name = 'logout_user'),
url(r'^register/$',views.register,name = 'register' ),
url(r'^profile/(?P<pk>[\w]+)/$',views.profile,name = 'profile'),
url(r'^profile/(?P<pk>[\w]+)/edit$',views.Update_View.as_view(),name = 'robust'),
url(r'^profile-details/$',views.profile_details,name = 'profile_details')


]